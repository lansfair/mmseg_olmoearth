#!/usr/bin/env python3
"""Diagnose the DINOv3 MMSeg project layout and registry imports."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path


REQUIRED_FILES = (
    "projects/DINOv3/__init__.py",
    "projects/DINOv3/datasets/pastis_pt_dataset.py",
    "projects/DINOv3/datasets/transforms.py",
    "projects/DINOv3/models/dinov3_vit.py",
    "projects/DINOv3/models/linear_probe_head.py",
    "projects/DINOv3/models/temporal_data_preprocessor.py",
    "projects/DINOv3/models/temporal_encoder_decoder.py",
    "projects/DINOv3/hooks/__init__.py",
    "projects/DINOv3/hooks/backbone_freeze_switch_hook.py",
)

MODULES = (
    "projects.DINOv3.datasets.pastis_pt_dataset",
    "projects.DINOv3.datasets.transforms",
    "projects.DINOv3.models.dinov3_vit",
    "projects.DINOv3.models.linear_probe_head",
    "projects.DINOv3.models.temporal_data_preprocessor",
    "projects.DINOv3.models.temporal_encoder_decoder",
    "projects.DINOv3.hooks.backbone_freeze_switch_hook",
)


def find_repo_root() -> Path:
    here = Path(__file__).resolve()
    # .../projects/DINOv3/test/diagnose_project_import.py -> repository root
    return here.parents[3]


def main() -> int:
    repo_root = find_repo_root()
    print(f"[diagnose] repository root: {repo_root}")

    missing = [name for name in REQUIRED_FILES if not (repo_root / name).is_file()]
    if missing:
        print("[diagnose] missing required files:")
        for name in missing:
            print(f"  - {name}")
        print("[diagnose] Replace the whole projects/DINOv3 directory with the patched package.")
        return 2

    repo_str = str(repo_root)
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)

    for name in MODULES:
        print(f"[diagnose] importing {name}")
        importlib.import_module(name)

    print("[diagnose] all project modules imported successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
