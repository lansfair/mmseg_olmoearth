#!/usr/bin/env python
from __future__ import annotations

import argparse
import shutil
import sys
import tempfile
from pathlib import Path

import torch


def make_fake_dataset(root: Path) -> None:
    for split in ('pastis_r_train', 'pastis_r_val', 'pastis_r_test'):
        image_root = root / split / 's2_images'
        image_root.mkdir(parents=True, exist_ok=True)
        targets = torch.randint(0, 19, (2, 64, 64), dtype=torch.long)
        targets[:, :4, :4] = -1
        torch.save(targets, root / split / 'targets.pt')
        for index in range(2):
            torch.save(
                torch.rand(12, 13, 64, 64) * 4000,
                image_root / f'{index}.pt',
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', default=None)
    parser.add_argument('--resize', type=int, nargs=2, default=(128, 128))
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parents[1]
    mmseg_root = project_root.parents[1]
    sys.path.insert(0, str(mmseg_root))
    import projects.DINOv3  # noqa: F401
    from mmseg.registry import DATASETS

    temp_dir = None
    if args.data_root is None:
        temp_dir = Path(tempfile.mkdtemp(prefix='pastis_fake_'))
        make_fake_dataset(temp_dir)
        data_root = temp_dir
    else:
        data_root = Path(args.data_root).expanduser().resolve()

    pipeline = [
        dict(type='LoadPastisSampleFromPT'),
        dict(type='PastisResize', size=tuple(args.resize)),
        dict(
            type='NormalizePastisFromJSON',
            stats_file=str(project_root / 'configs/pastis/NORM_S2_patch.json'),
            folds=('Fold_1', 'Fold_2', 'Fold_3'),
        ),
        dict(type='PastisPackSegInputs'),
    ]
    dataset = DATASETS.build(dict(
        type='PastisPTDataset',
        data_root=str(data_root),
        split='pastis_r_train',
        pipeline=pipeline,
        ignore_index=255,
    ))
    item = dataset[0]
    inputs = item['inputs']
    target = item['data_samples'].gt_sem_seg.data
    print(f'[OK] dataset length: {len(dataset)}')
    print(f'[OK] inputs: {tuple(inputs.shape)} {inputs.dtype}')
    print(f'[OK] target: {tuple(target.shape)} {target.dtype}')
    print(f'[OK] labels: {torch.unique(target).tolist()}')
    assert inputs.shape == (12, 13, args.resize[0], args.resize[1])
    assert target.shape == (1, args.resize[0], args.resize[1])
    assert 255 in torch.unique(target).tolist()

    if temp_dir is not None:
        shutil.rmtree(temp_dir)


if __name__ == '__main__':
    main()
