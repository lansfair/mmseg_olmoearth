"""DINOv3 project extensions for MMSegmentation.

Registration modules are imported explicitly by ``custom_imports`` in each
configuration. Keeping this package initializer side-effect free avoids
partially-initialized-package errors during MMEngine config loading.
"""

__all__ = []
