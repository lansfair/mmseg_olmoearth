# DINOv3 ViT-L/16 SAT493M + PASTIS temporal linear probe

This package is meant to be placed at:

```text
mmsegmentation/projects/DINOv3/
```

## Implemented path

```text
(B,T,13,H,W)
  -> shared learnable 1x1 projection (13 -> 3)
  -> each time step independently through DINOv3 ViT-L/16 SAT493M
  -> temporal feature fusion: mean or max
  -> one 1x1 linear segmentation classifier
  -> 19 classes, ignore_index=255
```

The normalization JSON contains ten-channel statistics. The pipeline averages
`Fold_1`, `Fold_2`, and `Fold_3`, then expands both the statistics (and a
10-channel image when needed) with:

```text
[0, 0, 1, 2, 3, 4, 5, 6, 7, 7, 8, 8, 9]
```

Validation and test use the same train-fold normalization statistics.

## User-editable config interfaces

At the top of either config, edit or export:

```bash
export PASTIS_DATA_ROOT=/absolute/path/to/pastis_dataset_64
export DINOV3_SAT493M_WEIGHTS=/absolute/path/to/dinov3_vitl16_pretrain_sat493m.pth
# Optional; a supplied default JSON is already in the project.
export PASTIS_NORM_STATS=/absolute/path/to/NORM_S2_patch.json
```

In the config, change:

```python
resize_size = (224, 224)  # None keeps the original 64x64
temporal_fusion = 'mean'  # or 'max'
```

The spatial size must be divisible by the ViT patch size 16. The resize
transform uses bilinear interpolation for all time-step images and nearest
interpolation for the segmentation label.

## Two training configs

1. First 10 epochs frozen, last 40 epochs full fine-tuning:

```text
projects/DINOv3/configs/pastis/
dinov3-vitl16_temporal-linear_1xb1-50e_pastis_freeze10.py
```

2. Frozen DINOv3 for all 50 epochs:

```text
projects/DINOv3/configs/pastis/
dinov3-vitl16_temporal-linear_1xb1-50e_pastis_frozen.py
```

The spectral projection and linear head remain trainable in both experiments.

## Run

Single GPU:

```bash
python tools/train.py \
  projects/DINOv3/configs/pastis/dinov3-vitl16_temporal-linear_1xb1-50e_pastis_frozen.py
```

Multi GPU (example: 4 GPUs):

```bash
bash tools/dist_train.sh \
  projects/DINOv3/configs/pastis/dinov3-vitl16_temporal-linear_1xb1-50e_pastis_freeze10.py \
  4
```

Each config's `batch_size=1` is per GPU. The phase-switching config sets
`find_unused_parameters=True` so dynamic freeze/unfreeze works under DDP.

Override interfaces from the command line, for example:

```bash
python tools/train.py CONFIG.py --cfg-options \
  temporal_fusion=max \
  resize_size='(256,256)' \
  train_dataloader.batch_size=1
```

## Pipeline test

From the MMSegmentation root:

```bash
python projects/DINOv3/test/test_pastis_temporal_pipeline.py
```

This creates fake `(12,13,64,64)` samples and checks loading, resize,
normalization, packing, and ignore-label conversion. Use real data with:

```bash
python projects/DINOv3/test/test_pastis_temporal_pipeline.py \
  --data-root /absolute/path/to/pastis_dataset_64 \
  --resize 224 224
```

## Notes

- Model weights and PASTIS data are not included.
- The linear head is deliberately only a `1x1 Conv2d`.
- With `224x224` input, ViT-L/16 produces a `14x14` token feature map; MMSeg
  resizes logits to the label resolution for loss and prediction.
- The package keeps the official DINOv3 source uploaded with the project.

## Import-error fix in v2

Do not overlay only a few files on an older `projects/DINOv3` directory.
Replace the whole directory so that `hooks/`, `datasets/`, and `models/` all
come from the same package version:

```bash
rm -rf projects/DINOv3
cp -r /path/to/extracted/DINOv3 projects/DINOv3
```

Then run the import diagnostic from the MMSegmentation repository root:

```bash
python projects/DINOv3/test/diagnose_project_import.py
```

The root `projects/DINOv3/__init__.py` is intentionally side-effect free.
Each config imports the concrete registry modules through `custom_imports`.
