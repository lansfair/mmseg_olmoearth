from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Iterable, Sequence

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

from mmengine.structures import PixelData
from mmseg.registry import DATASETS
from mmseg.structures import SegDataSample


PASTIS_CLASSES = (
    "background",
    "meadow",
    "soft_winter_wheat",
    "corn",
    "winter_barley",
    "winter_rapeseed",
    "spring_barley",
    "sunflower",
    "grapevine",
    "beet",
    "winter_triticale",
    "winter_durum_wheat",
    "fruits_vegetables_flowers",
    "potatoes",
    "leguminous_fodder",
    "soybeans",
    "orchard",
    "mixed_cereal",
    "sorghum",
)

# 简单稳定的 19 类 palette，主要用于可视化占位。
PASTIS_PALETTE = [
    [0, 0, 0],
    [128, 255, 0],
    [255, 255, 0],
    [255, 165, 0],
    [190, 190, 0],
    [255, 0, 255],
    [180, 255, 180],
    [255, 220, 0],
    [150, 75, 0],
    [255, 0, 0],
    [180, 180, 80],
    [210, 210, 120],
    [255, 120, 180],
    [160, 80, 160],
    [0, 180, 0],
    [0, 150, 150],
    [80, 120, 40],
    [120, 120, 120],
    [200, 100, 60],
]

# 10 通道 S2 统计量 -> 13 标准波段的扩展映射。
# 13 通道顺序假设为:
# [B1, B2, B3, B4, B5, B6, B7, B8, B8A, B9, B10, B11, B12]
# 10 通道顺序假设为:
# [B2, B3, B4, B5, B6, B7, B8, B8A, B11, B12]
BAND10_TO_BAND13 = (0, 0, 1, 2, 3, 4, 5, 6, 7, 7, 8, 8, 9)


def _numeric_sort_key(path: Path):
    match = re.fullmatch(r"\d+", path.stem)
    return (0, int(path.stem)) if match else (1, path.stem)


def _load_tensor(path: Path):
    obj = torch.load(path, map_location="cpu")
    if torch.is_tensor(obj):
        return obj
    if isinstance(obj, dict):
        for key in ("image", "img", "data", "x", "tensor"):
            if key in obj and torch.is_tensor(obj[key]):
                return obj[key]
    raise TypeError(f"Unsupported tensor file format: {path}")


def _mean_std_from_json(norm_cfg_path: str | os.PathLike, fold_keys: Sequence[str]):
    with open(norm_cfg_path, "r", encoding="utf-8") as f:
        stats = json.load(f)

    means, stds = [], []
    for key in fold_keys:
        if key not in stats:
            raise KeyError(f"{key!r} is missing from normalization JSON.")
        mean = torch.as_tensor(stats[key]["mean"], dtype=torch.float32)
        std = torch.as_tensor(stats[key]["std"], dtype=torch.float32)
        if mean.numel() != 10 or std.numel() != 10:
            raise ValueError(
                f"{key} should contain 10 mean/std values, got "
                f"{mean.numel()} and {std.numel()}."
            )
        means.append(mean)
        stds.append(std)

    return torch.stack(means, dim=0).mean(dim=0), torch.stack(stds, dim=0).mean(dim=0)


@DATASETS.register_module()
class PastisTemporalDataset(Dataset):
    """PASTIS temporal semantic segmentation dataset for preprocessed .pt files.

    Expected layout:
        data_root/
        ├── pastis_r_train/
        │   ├── imgs/
        │   │   ├── 0.pt
        │   │   ├── 1.pt
        │   │   └── ...
        │   └── targets.pt
        ├── pastis_r_valid/
        │   ├── imgs/
        │   └── targets.pt
        └── pastis_r_test/
            ├── imgs/
            └── targets.pt

    Each image .pt tensor is expected to be T×C×H×W, usually 12×13×64×64
    or 12×10×64×64. If C=10 and ``expand_to_13=True``, channels are expanded
    to the 13-band standard layout before the model selects RGB.
    """

    METAINFO = dict(classes=PASTIS_CLASSES, palette=PASTIS_PALETTE)

    def __init__(
        self,
        data_root: str,
        split: str,
        img_dir: str = "imgs",
        label_file: str = "targets.pt",
        norm_cfg_path: str | None = None,
        norm_fold_keys: Sequence[str] = ("Fold_1", "Fold_2", "Fold_3"),
        resize_size: tuple[int, int] | None = None,
        expand_to_13: bool = True,
        ignore_label_values: Iterable[int] = (-1,),
        ignore_index: int = 255,
        metainfo: dict | None = None,
        **kwargs,
    ):
        super().__init__()
        self.data_root = Path(data_root)
        self.split = split
        self.split_dir = self.data_root / split
        self.img_dir = self.split_dir / img_dir
        self.label_path = self.split_dir / label_file
        self.norm_cfg_path = norm_cfg_path
        self.norm_fold_keys = tuple(norm_fold_keys)
        self.resize_size = tuple(resize_size) if resize_size is not None else None
        self.expand_to_13 = bool(expand_to_13)
        self.ignore_label_values = tuple(int(v) for v in ignore_label_values)
        self.ignore_index = int(ignore_index)
        self._metainfo = dict(self.METAINFO)
        if metainfo:
            self._metainfo.update(metainfo)

        if not self.img_dir.is_dir():
            raise FileNotFoundError(f"Image directory not found: {self.img_dir}")
        if not self.label_path.is_file():
            raise FileNotFoundError(f"Target tensor not found: {self.label_path}")

        self.img_paths = sorted(self.img_dir.glob("*.pt"), key=_numeric_sort_key)
        if len(self.img_paths) == 0:
            raise FileNotFoundError(f"No .pt image files found in {self.img_dir}")

        targets = torch.load(self.label_path, map_location="cpu")
        if isinstance(targets, dict):
            for key in ("targets", "target", "mask", "masks", "label", "labels"):
                if key in targets and torch.is_tensor(targets[key]):
                    targets = targets[key]
                    break
        if not torch.is_tensor(targets):
            raise TypeError(f"Unsupported target file format: {self.label_path}")
        if targets.ndim != 3:
            raise ValueError(f"targets.pt should have shape N×H×W, got {tuple(targets.shape)}")
        if targets.shape[0] < len(self.img_paths):
            raise ValueError(
                f"targets.pt has {targets.shape[0]} masks but {len(self.img_paths)} images were found."
            )
        self.targets = targets.long()

        self.mean10 = None
        self.std10 = None
        if norm_cfg_path:
            self.mean10, self.std10 = _mean_std_from_json(norm_cfg_path, self.norm_fold_keys)
            self.std10 = torch.clamp(self.std10, min=1e-6)

    @property
    def metainfo(self):
        return self._metainfo

    def __len__(self):
        return len(self.img_paths)

    def _normalize_and_expand(self, img: torch.Tensor) -> torch.Tensor:
        # img: T×C×H×W
        if img.ndim != 4:
            raise ValueError(f"Image tensor should have shape T×C×H×W, got {tuple(img.shape)}")
        img = img.float()
        c = img.shape[1]

        if self.mean10 is None or self.std10 is None:
            if c == 10 and self.expand_to_13:
                index = torch.as_tensor(BAND10_TO_BAND13, dtype=torch.long)
                img = img[:, index, :, :]
            return img

        if c == 10:
            if self.expand_to_13:
                index = torch.as_tensor(BAND10_TO_BAND13, dtype=torch.long)
                img = img[:, index, :, :]
                mean = self.mean10[index]
                std = self.std10[index]
            else:
                mean = self.mean10
                std = self.std10
        elif c == 13:
            index = torch.as_tensor(BAND10_TO_BAND13, dtype=torch.long)
            mean = self.mean10[index]
            std = self.std10[index]
        else:
            raise ValueError(
                f"Only 10-band or 13-band PASTIS tensors are supported, got C={c}."
            )

        return (img - mean.view(1, -1, 1, 1)) / std.view(1, -1, 1, 1)

    def _resize(self, img: torch.Tensor, mask: torch.Tensor):
        if self.resize_size is None:
            return img, mask

        size = tuple(int(v) for v in self.resize_size)
        img = F.interpolate(img, size=size, mode="bilinear", align_corners=False)
        mask = F.interpolate(
            mask[None, None].float(),
            size=size,
            mode="nearest",
        )[0, 0].long()
        return img, mask

    def __getitem__(self, idx: int):
        img_path = self.img_paths[idx]
        img = _load_tensor(img_path)
        mask = self.targets[idx].clone().long()

        if img.ndim == 3:
            img = img.unsqueeze(0)
        if img.ndim != 4:
            raise ValueError(f"{img_path} should contain T×C×H×W, got {tuple(img.shape)}")

        ori_shape = tuple(mask.shape[-2:])
        img = self._normalize_and_expand(img)
        mask = mask.clone()
        for value in self.ignore_label_values:
            mask[mask == value] = self.ignore_index

        img, mask = self._resize(img, mask)
        img_shape = tuple(mask.shape[-2:])

        data_sample = SegDataSample()
        data_sample.gt_sem_seg = PixelData(data=mask.unsqueeze(0))
        data_sample.set_metainfo(
            dict(
                img_path=str(img_path),
                seg_map_path=str(self.label_path),
                sample_idx=idx,
                ori_shape=ori_shape,
                img_shape=img_shape,
                pad_shape=img_shape,
                reduce_zero_label=False,
            )
        )

        return dict(inputs=img.contiguous(), data_samples=data_sample)
