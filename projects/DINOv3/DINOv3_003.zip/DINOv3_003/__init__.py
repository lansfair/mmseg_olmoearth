"""DINOv3 MMSegmentation project package.

The root package intentionally stays lightweight.
Registry modules are imported explicitly from config custom_imports:
- projects.DINOv3.datasets
- projects.DINOv3.models
- projects.DINOv3.hooks
"""
