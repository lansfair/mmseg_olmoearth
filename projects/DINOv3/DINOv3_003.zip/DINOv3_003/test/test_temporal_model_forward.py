#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights-path", default=None)
    parser.add_argument("--fusion", choices=["mean", "max"], default="mean")
    parser.add_argument("--size", type=int, default=224)
    parser.add_argument("--timesteps", type=int, default=12)
    parser.add_argument("--channels", type=int, choices=[10, 13], default=13)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parents[1]
    repo_root = project_dir.parents[1]
    for p in (str(repo_root), str(project_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)

    from projects.DINOv3.models.temporal_dinov3_rgb_backbone import TemporalDINOv3RGBBackbone

    model = TemporalDINOv3RGBBackbone(
        checkpoint_path=args.weights_path,
        repo_path=str(project_dir),
        temporal_fusion=args.fusion,
        freeze_backbone=True,
        require_checkpoint=args.weights_path is not None,
    ).to(args.device)

    x = torch.randn(1, args.timesteps, args.channels, args.size, args.size, device=args.device)
    with torch.no_grad():
        feats = model(x)
    print(f"[OK] outputs={len(feats)}")
    for i, feat in enumerate(feats):
        print(f"[OK] feat[{i}] shape={tuple(feat.shape)}")


if __name__ == "__main__":
    main()
