#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--norm-file", default=None)
    parser.add_argument("--split", default="pastis_r_train")
    parser.add_argument("--resize", nargs=2, type=int, default=None)
    parser.add_argument("--index", type=int, default=0)
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parents[1]
    repo_root = project_dir.parents[1]
    for p in (str(repo_root), str(project_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)

    from projects.DINOv3.datasets import PastisTemporalDataset

    dataset = PastisTemporalDataset(
        data_root=args.data_root,
        split=args.split,
        norm_cfg_path=args.norm_file,
        resize_size=tuple(args.resize) if args.resize else None,
        expand_to_13=True,
    )
    sample = dataset[args.index]
    x = sample["inputs"]
    y = sample["data_samples"].gt_sem_seg.data
    print(f"[OK] len={len(dataset)}")
    print(f"[OK] inputs shape={tuple(x.shape)} dtype={x.dtype}")
    print(f"[OK] mask shape={tuple(y.shape)} labels min/max={int(y.min())}/{int(y.max())}")


if __name__ == "__main__":
    main()
