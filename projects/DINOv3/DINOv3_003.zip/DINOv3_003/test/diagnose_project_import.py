#!/usr/bin/env python3
from __future__ import annotations

import importlib
import sys
from pathlib import Path


def main():
    project_dir = Path(__file__).resolve().parents[1]
    repo_root = project_dir.parents[1]
    for p in (str(repo_root), str(project_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)

    modules = [
        "projects.DINOv3.datasets",
        "projects.DINOv3.models",
        "projects.DINOv3.hooks",
    ]
    for name in modules:
        importlib.import_module(name)
        print(f"[OK] imported {name}")

    required = [
        project_dir / "dinov3" / "hub" / "backbones.py",
        project_dir / "datasets" / "pastis_temporal_dataset.py",
        project_dir / "models" / "temporal_dinov3_rgb_backbone.py",
        project_dir / "hooks" / "backbone_freeze_switch_hook.py",
    ]
    for path in required:
        if not path.exists():
            raise FileNotFoundError(path)
        print(f"[OK] exists {path.relative_to(project_dir)}")

    print("[diagnose] all project modules imported successfully.")


if __name__ == "__main__":
    main()
