import os
import os.path as osp

default_scope = "mmseg"

project_dir = osp.abspath(osp.join(osp.dirname(__file__), "../.."))

data_root = os.getenv("PASTIS_DATA_ROOT", "/path/to/pastis_dataset_64")
norm_cfg_path = os.getenv(
    "PASTIS_NORM_STATS",
    osp.join(project_dir, "assets", "NORM_S2_patch.json"),
)
dinov3_weights_path = os.getenv(
    "DINOV3_SAT493M_WEIGHTS",
    "/path/to/dinov3_vitl16_pretrain_sat493m.pth",
)
dinov3_repo_path = os.getenv("DINOV3_REPO_PATH", project_dir)

resize_size = (224, 224)  # 可改为 None；建议 H/W 能被 16 整除
temporal_fusion = "mean"  # "mean" 或 "max"
batch_size = 1
num_workers = 2
num_classes = 19
ignore_index = 255

custom_imports = dict(
    imports=[
        "projects.DINOv3.datasets",
        "projects.DINOv3.models",
        "projects.DINOv3.hooks",
    ],
    allow_failed_imports=False,
)

model = dict(
    type="EncoderDecoder",
    data_preprocessor=dict(type="PastisDataPreProcessor"),
    backbone=dict(
        type="TemporalDINOv3RGBBackbone",
        model_name="dinov3_vitl16",
        weights_name="SAT493M",
        checkpoint_path=dinov3_weights_path,
        repo_path=dinov3_repo_path,
        out_indices=(23,),
        temporal_fusion=temporal_fusion,
        # 最新版本：固定只选 RGB 三通道送入 DINOv3
        # 13 通道输入取 [B4, B3, B2] -> indices (3,2,1)
        # 10 通道输入取 [B4, B3, B2] -> indices (2,1,0)
        rgb_indices_13=(3, 2, 1),
        rgb_indices_10=(2, 1, 0),
        freeze_backbone=True,
        require_checkpoint=True,
        load_strict=True,
    ),
    decode_head=dict(
        type="LinearProbeHead",
        in_channels=1024,
        channels=1024,
        in_index=0,
        num_classes=num_classes,
        dropout_ratio=0.0,
        ignore_index=ignore_index,
        align_corners=False,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"),
)

dataset_type = "PastisTemporalDataset"

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        split="pastis_r_train",
        norm_cfg_path=norm_cfg_path,
        norm_fold_keys=("Fold_1", "Fold_2", "Fold_3"),
        resize_size=resize_size,
        expand_to_13=True,
        ignore_label_values=(-1,),
        ignore_index=ignore_index,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        split="pastis_r_valid",
        norm_cfg_path=norm_cfg_path,
        norm_fold_keys=("Fold_1", "Fold_2", "Fold_3"),
        resize_size=resize_size,
        expand_to_13=True,
        ignore_label_values=(-1,),
        ignore_index=ignore_index,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=num_workers,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        split="pastis_r_test",
        norm_cfg_path=norm_cfg_path,
        norm_fold_keys=("Fold_1", "Fold_2", "Fold_3"),
        resize_size=resize_size,
        expand_to_13=True,
        ignore_label_values=(-1,),
        ignore_index=ignore_index,
    ),
)

val_evaluator = dict(type="IoUMetric", iou_metrics=["mIoU"])
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(type="AdamW", lr=1e-4, weight_decay=0.05),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(type="CosineAnnealingLR", T_max=50, eta_min=1e-6, by_epoch=True)
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=50, val_interval=1)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=20, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(type="CheckpointHook", by_epoch=True, interval=5, save_best="mIoU"),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="SegVisualizationHook"),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(type="SegLocalVisualizer", vis_backends=vis_backends, name="visualizer")

log_processor = dict(by_epoch=True)
log_level = "INFO"
load_from = None
resume = False


# 配置 1：前 10 epoch 冻结 DINOv3，第 11 个 epoch 开始全量训练，总共 50 epoch。
model["backbone"]["freeze_backbone"] = True

# 动态冻结/解冻时，DDP 建议打开 find_unused_parameters。
model_wrapper_cfg = dict(type="MMDistributedDataParallel", find_unused_parameters=True)

custom_hooks = [
    dict(
        type="BackboneFreezeSwitchHook",
        unfreeze_epoch=10,
        module_path="backbone",
        set_eval_during_freeze=True,
    )
]
