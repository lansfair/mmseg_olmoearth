# DINOv3 + PASTIS Temporal Linear Probe (RGB-only)

这一版是根据最新要求重新生成的完整 `projects/DINOv3/` 文件包：

```text
输入: B × T × 13 × H × W 或 B × T × 10 × H × W
13 通道时固定选取 RGB = [B4, B3, B2]，索引 (3, 2, 1)
10 通道时固定选取 RGB = [B4, B3, B2]，索引 (2, 1, 0)
每个时相单独送入 DINOv3 ViT-L/16 SAT493M
T 个时相特征用 mean 或 max 融合
最后使用 Linear Probe 1×1 Conv 解码
```

注意：这版 **不是 13→3 可学习投影**，也 **不是删除 RGB 后用 10 通道**。这版是 **只保留 RGB 三通道送入 DINOv3**。

## 放置方式

在 MMSegmentation 仓库根目录执行：

```bash
rm -rf projects/DINOv3
unzip DINOv3_pastis_rgb_only_complete_regenerated.zip -d projects/
```

最终目录应为：

```text
mmsegmentation/projects/DINOv3/
```

不要解压成：

```text
mmsegmentation/projects/DINOv3/DINOv3/
```

## 环境变量

```bash
export PASTIS_DATA_ROOT=/path/to/pastis_dataset_64
export DINOV3_SAT493M_WEIGHTS=/path/to/dinov3_vitl16_pretrain_sat493m.pth
# 可选；包内已带一份默认 JSON
export PASTIS_NORM_STATS=/path/to/NORM_S2_patch.json
```

如果不设置 `PASTIS_NORM_STATS`，配置会默认读取：

```text
projects/DINOv3/assets/NORM_S2_patch.json
```

## 两份配置

```text
projects/DINOv3/configs/pastis/
├── dinov3-vitl16_temporal-linear_1xb1-50e_pastis_rgb-only_freeze10.py
└── dinov3-vitl16_temporal-linear_1xb1-50e_pastis_rgb-only_frozen.py
```

第一份：前 10 epoch 冻结 DINOv3，第 11 epoch 开始全量训练，总共 50 epoch。  
第二份：全程冻结 DINOv3，只训练 Linear Probe 头，总共 50 epoch。

## 训练

单卡：

```bash
python tools/train.py \
  projects/DINOv3/configs/pastis/dinov3-vitl16_temporal-linear_1xb1-50e_pastis_rgb-only_frozen.py
```

多卡：

```bash
bash tools/dist_train.sh \
  projects/DINOv3/configs/pastis/dinov3-vitl16_temporal-linear_1xb1-50e_pastis_rgb-only_freeze10.py 4
```

## 诊断

```bash
python projects/DINOv3/test/diagnose_project_import.py
```

数据读取测试：

```bash
python projects/DINOv3/test/test_pastis_temporal_dataset.py \
  --data-root $PASTIS_DATA_ROOT \
  --norm-file $PASTIS_NORM_STATS \
  --split pastis_r_train \
  --resize 224 224
```

模型 forward 测试：

```bash
python projects/DINOv3/test/test_temporal_model_forward.py \
  --weights-path $DINOV3_SAT493M_WEIGHTS \
  --fusion mean \
  --size 224
```

## 关键接口

在配置文件顶部可改：

```python
resize_size = (224, 224)  # 或 None
temporal_fusion = "mean"  # 或 "max"
```

输入尺寸的高和宽建议能被 DINOv3 ViT-L/16 的 patch size 16 整除。
