from __future__ import annotations

from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


@MODELS.register_module()
class LinearProbeHead(BaseDecodeHead):
    """A strict linear segmentation head.

    The head applies only the BaseDecodeHead classifier conv (1×1 Conv) to the
    selected frozen or fine-tuned DINOv3 feature. No nonlinear decoder/neck is
    introduced.
    """

    def __init__(self, **kwargs):
        super().__init__(input_transform=None, **kwargs)

    def forward(self, inputs):
        x = self._transform_inputs(inputs)
        return self.cls_seg(x)
