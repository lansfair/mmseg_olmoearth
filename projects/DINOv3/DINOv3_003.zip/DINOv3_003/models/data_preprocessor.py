from __future__ import annotations

from typing import Any

import torch
from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS


@MODELS.register_module()
class PastisDataPreProcessor(BaseDataPreprocessor):
    """Minimal data preprocessor for temporal PASTIS tensors.

    It keeps the input shape as B×T×C×H×W and only moves/casts data to device.
    Resizing and normalization are handled in ``PastisTemporalDataset`` because
    they must be synchronized with the temporal tensor and label map.
    """

    def __init__(self, non_blocking: bool = True):
        super().__init__(non_blocking=non_blocking)

    def forward(self, data: dict[str, Any], training: bool = False):
        data = self.cast_data(data)
        inputs = data["inputs"]

        if isinstance(inputs, (list, tuple)):
            inputs = torch.stack(list(inputs), dim=0)

        if not torch.is_tensor(inputs):
            raise TypeError(f"inputs should be a Tensor or a list of Tensors, got {type(inputs)}")
        if inputs.ndim != 5:
            raise ValueError(
                f"PastisDataPreProcessor expects B×T×C×H×W, got {tuple(inputs.shape)}"
            )

        return dict(inputs=inputs.float(), data_samples=data.get("data_samples", None))
