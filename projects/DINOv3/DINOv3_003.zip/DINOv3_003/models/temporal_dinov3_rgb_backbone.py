from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Sequence

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS


def _strip_prefix_if_present(state_dict: dict, prefix: str):
    if not any(k.startswith(prefix) for k in state_dict):
        return state_dict
    return {k[len(prefix):]: v for k, v in state_dict.items() if k.startswith(prefix)}


def _extract_state_dict(checkpoint):
    if isinstance(checkpoint, dict):
        for key in ("state_dict", "model", "teacher", "student"):
            if key in checkpoint and isinstance(checkpoint[key], dict):
                return checkpoint[key]
    return checkpoint


@MODELS.register_module()
class TemporalDINOv3RGBBackbone(BaseModule):
    """Temporal DINOv3 backbone for PASTIS with fixed RGB band selection.

    Input:
        B×T×13×H×W or B×T×10×H×W

    RGB selection:
        - 13 channels: indices (3, 2, 1), i.e. B4/B3/B2 -> RGB
        - 10 channels: indices (2, 1, 0), i.e. B4/B3/B2 -> RGB

    Each temporal slice is encoded independently by the same DINOv3 model.
    Features are then fused across time using ``mean`` or ``max``.
    """

    def __init__(
        self,
        model_name: str = "dinov3_vitl16",
        weights_name: str = "SAT493M",
        checkpoint_path: str | None = None,
        repo_path: str | None = None,
        out_indices: Sequence[int] = (23,),
        temporal_fusion: str = "mean",
        rgb_indices_13: Sequence[int] = (3, 2, 1),
        rgb_indices_10: Sequence[int] = (2, 1, 0),
        freeze_backbone: bool = True,
        require_checkpoint: bool = True,
        load_strict: bool = True,
        set_eval_during_freeze: bool = True,
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        if temporal_fusion not in ("mean", "max"):
            raise ValueError("temporal_fusion must be 'mean' or 'max'.")

        self.model_name = model_name
        self.weights_name = weights_name
        self.checkpoint_path = checkpoint_path
        self.repo_path = repo_path
        self.out_indices = tuple(int(i) for i in out_indices)
        self.temporal_fusion = temporal_fusion
        self.rgb_indices_13 = tuple(int(i) for i in rgb_indices_13)
        self.rgb_indices_10 = tuple(int(i) for i in rgb_indices_10)
        self.require_checkpoint = bool(require_checkpoint)
        self.load_strict = bool(load_strict)
        self.set_eval_during_freeze = bool(set_eval_during_freeze)

        self.dino = self._build_official_dinov3()
        self.embed_dim = int(getattr(self.dino, "embed_dim", 1024))
        self.out_channels = self.embed_dim
        self.patch_size = int(getattr(self.dino, "patch_size", 16))

        self._load_checkpoint_if_needed()
        self.backbone_frozen = False
        self.set_backbone_trainable(not freeze_backbone)

    def _candidate_repo_paths(self):
        here = Path(__file__).resolve()
        project_root = here.parents[1]
        candidates = []
        if self.repo_path:
            candidates.append(Path(self.repo_path).expanduser().resolve())
        candidates.extend(
            [
                project_root,
                project_root / "dinov3",
                project_root / "dinov3-main",
                project_root / "third_party" / "dinov3",
            ]
        )
        return candidates

    def _build_official_dinov3(self):
        selected = None
        for candidate in self._candidate_repo_paths():
            if (candidate / "dinov3" / "hub" / "backbones.py").is_file():
                selected = candidate
                break

        if selected is None:
            searched = "\n".join(str(p) for p in self._candidate_repo_paths())
            raise FileNotFoundError(
                "Could not find official DINOv3 source. Searched:\n" + searched
            )

        selected_str = str(selected)
        if selected_str not in sys.path:
            sys.path.insert(0, selected_str)

        from dinov3.hub import backbones as dino_backbones

        if not hasattr(dino_backbones, self.model_name):
            names = sorted(n for n in dir(dino_backbones) if n.startswith("dinov3_"))
            raise ValueError(
                f"Unsupported DINOv3 model_name={self.model_name!r}. Available: {names}"
            )

        weights = getattr(dino_backbones.Weights, self.weights_name)
        builder = getattr(dino_backbones, self.model_name)
        return builder(pretrained=False, weights=weights, check_hash=False)

    def _load_checkpoint_if_needed(self):
        path = self.checkpoint_path
        if path is None or str(path).strip() == "":
            if self.require_checkpoint:
                raise FileNotFoundError(
                    "checkpoint_path is required. Set DINOV3_SAT493M_WEIGHTS or edit the config."
                )
            return

        path = Path(os.path.expanduser(str(path)))
        if not path.is_file():
            if self.require_checkpoint:
                raise FileNotFoundError(f"DINOv3 checkpoint not found: {path}")
            return

        checkpoint = torch.load(path, map_location="cpu")
        state_dict = _extract_state_dict(checkpoint)
        state_dict = _strip_prefix_if_present(state_dict, "module.")
        state_dict = _strip_prefix_if_present(state_dict, "backbone.")
        missing, unexpected = self.dino.load_state_dict(state_dict, strict=self.load_strict)
        if missing or unexpected:
            print(
                "[TemporalDINOv3RGBBackbone] checkpoint load info: "
                f"missing={len(missing)}, unexpected={len(unexpected)}"
            )

    def set_backbone_trainable(self, trainable: bool):
        trainable = bool(trainable)
        for p in self.dino.parameters():
            p.requires_grad = trainable
        self.backbone_frozen = not trainable
        if self.backbone_frozen and self.set_eval_during_freeze:
            self.dino.eval()
        return self

    def train(self, mode: bool = True):
        super().train(mode)
        if self.backbone_frozen and self.set_eval_during_freeze:
            self.dino.eval()
        return self

    def _select_rgb(self, x: torch.Tensor):
        # x: B×T×C×H×W
        c = x.shape[2]
        if c == 13:
            index = self.rgb_indices_13
        elif c == 10:
            index = self.rgb_indices_10
        else:
            raise ValueError(f"Expected 10 or 13 input channels, got C={c}.")
        return x[:, :, index, :, :]

    def _forward_dino(self, x_rgb: torch.Tensor):
        # x_rgb: (B*T)×3×H×W
        return self.dino.get_intermediate_layers(
            x_rgb,
            n=self.out_indices,
            reshape=True,
            return_class_token=False,
            return_extra_tokens=False,
            norm=True,
        )

    def _fuse_temporal(self, feat: torch.Tensor, batch_size: int, timesteps: int):
        # feat: (B*T)×C×h×w -> B×C×h×w
        feat = feat.view(batch_size, timesteps, feat.shape[1], feat.shape[2], feat.shape[3])
        if self.temporal_fusion == "mean":
            return feat.mean(dim=1)
        return feat.max(dim=1).values

    def forward(self, x: torch.Tensor):
        if x.ndim != 5:
            raise ValueError(f"Expected B×T×C×H×W input, got {tuple(x.shape)}")

        b, t, c, h, w = x.shape
        x_rgb = self._select_rgb(x).reshape(b * t, 3, h, w).contiguous()

        if self.backbone_frozen:
            with torch.no_grad():
                feats = self._forward_dino(x_rgb)
        else:
            feats = self._forward_dino(x_rgb)

        fused = tuple(self._fuse_temporal(feat, b, t) for feat in feats)
        return fused
