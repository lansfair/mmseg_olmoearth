from __future__ import annotations

from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class BackboneFreezeSwitchHook(Hook):
    """Freeze DINOv3 for early epochs, then unfreeze it.

    ``unfreeze_epoch`` is zero-based in MMEngine's internal epoch counter.
    For "前10轮冻结，后40轮全量训练", set ``unfreeze_epoch=10``.
    """

    priority = "NORMAL"

    def __init__(
        self,
        unfreeze_epoch: int = 10,
        module_path: str = "backbone",
        set_eval_during_freeze: bool = True,
    ):
        self.unfreeze_epoch = int(unfreeze_epoch)
        self.module_path = module_path
        self.set_eval_during_freeze = bool(set_eval_during_freeze)
        self._has_unfrozen = False

    def _unwrap_model(self, model):
        return model.module if hasattr(model, "module") else model

    def _get_target(self, runner):
        target = self._unwrap_model(runner.model)
        for part in self.module_path.split("."):
            target = getattr(target, part)
        return target

    def before_train(self, runner):
        target = self._get_target(runner)
        if hasattr(target, "set_eval_during_freeze"):
            target.set_eval_during_freeze = self.set_eval_during_freeze
        if hasattr(target, "set_backbone_trainable"):
            target.set_backbone_trainable(False)
        runner.logger.info(
            f"BackboneFreezeSwitchHook: frozen until epoch {self.unfreeze_epoch}."
        )

    def before_train_epoch(self, runner):
        if self._has_unfrozen:
            return
        if runner.epoch >= self.unfreeze_epoch:
            target = self._get_target(runner)
            if hasattr(target, "set_backbone_trainable"):
                target.set_backbone_trainable(True)
            self._has_unfrozen = True
            runner.logger.info(
                f"BackboneFreezeSwitchHook: unfroze backbone at epoch {runner.epoch}."
            )
